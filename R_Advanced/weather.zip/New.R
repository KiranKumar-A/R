getwd()

setwd("G:/UDEMY/R Advanced")

getwd()

import.csv("Future-500.csv")
import.csv("Machine-Utilization.csv")
